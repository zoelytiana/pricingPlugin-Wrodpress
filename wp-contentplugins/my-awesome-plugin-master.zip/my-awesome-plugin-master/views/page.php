<h1><?php echo __( 'My Awesome Plugin', 'my-awesome-plugin' ); ?></h1>
<p><?php echo __( 'Welcome to My Awesome Plugin', 'my-awesome-plugin' ); ?></p>