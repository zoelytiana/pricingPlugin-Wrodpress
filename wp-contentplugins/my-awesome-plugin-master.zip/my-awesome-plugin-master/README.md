Comment créer un module / une extension WordPress ?
===========================================

Extension de test créer dans le cadre de l'article de blog https://www.undefined.fr/comment-creer-un-module-wordpress